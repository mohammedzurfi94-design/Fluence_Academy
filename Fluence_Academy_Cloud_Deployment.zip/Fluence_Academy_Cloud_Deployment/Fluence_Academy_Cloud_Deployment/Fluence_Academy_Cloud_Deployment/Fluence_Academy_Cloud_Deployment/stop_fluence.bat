@echo off
title Stop Fluence Academy
echo Stopping Fluence Academy background processes...
taskkill /f /im python.exe /fi "WINDOWTITLE eq Fluence Academy*" >nul 2>&1
echo Done.
pause
