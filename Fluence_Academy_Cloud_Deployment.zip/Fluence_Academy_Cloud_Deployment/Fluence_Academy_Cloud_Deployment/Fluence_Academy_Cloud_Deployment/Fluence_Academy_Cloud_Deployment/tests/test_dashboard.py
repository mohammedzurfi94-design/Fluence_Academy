import urllib.request
import urllib.parse
import http.cookiejar
import sys

# Ensure UTF-8 output
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

BASE_URL = "http://127.0.0.1:8000"

def run_dashboard_tests():
    print("=" * 65)
    print("🧪 WEB ADMIN DASHBOARD INTEGRATION TEST")
    print("=" * 65)

    cj = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

    # Test 1: GET /login
    print("\n[Test 1/6] Testing GET /login...")
    res = opener.open(f"{BASE_URL}/login")
    assert res.status == 200, f"Expected 200, got {res.status}"
    content = res.read().decode("utf-8")
    assert "Sign In to Dashboard" in content
    print("✅ PASS: Login page rendered cleanly with HTTP 200.")

    # Test 2: POST /login
    print("\n[Test 2/6] Testing POST /login with admin credentials...")
    login_data = urllib.parse.urlencode({"username": "admin", "password": "adminpassword123"}).encode("utf-8")
    req = urllib.request.Request(f"{BASE_URL}/login", data=login_data, method="POST")
    res = opener.open(req)
    assert res.status == 200, f"Expected 200 after redirect, got {res.status}"
    print("✅ PASS: Authenticated successfully, session cookie acquired.")

    # Test 3: GET / (Dashboard Overview)
    print("\n[Test 3/6] Testing authenticated GET / (Overview)...")
    res = opener.open(f"{BASE_URL}/")
    assert res.status == 200
    html = res.read().decode("utf-8")
    assert "Academy Overview" in html
    assert "Published Courses" in html
    print("✅ PASS: Overview metrics and recent activity rendered.")

    # Test 4: GET /students
    print("\n[Test 4/6] Testing GET /students...")
    res = opener.open(f"{BASE_URL}/students")
    assert res.status == 200
    html = res.read().decode("utf-8")
    assert "Student Management" in html
    print("✅ PASS: Student roster & subscription table rendered.")

    # Test 5: GET /courses
    print("\n[Test 5/6] Testing GET /courses...")
    res = opener.open(f"{BASE_URL}/courses")
    assert res.status == 200
    html = res.read().decode("utf-8")
    assert "English Fluency Foundation" in html
    print("✅ PASS: Courses catalog and syllabus rendered.")

    # Test 6: GET /announcements
    print("\n[Test 6/7] Testing GET /announcements...")
    res = opener.open(f"{BASE_URL}/announcements")
    assert res.status == 200
    html = res.read().decode("utf-8")
    assert "Academy Broadcast Center" in html
    print("✅ PASS: Broadcast announcements page rendered.")

    # Test 7: POST /backups/create
    print("\n[Test 7/7] Testing POST /backups/create...")
    req = urllib.request.Request(f"{BASE_URL}/backups/create", data=b"", method="POST")
    res = opener.open(req)
    assert res.status == 200
    html = res.read().decode("utf-8")
    assert "Available Backup Snapshots" in html
    assert "fluence_backup_" in html
    print("✅ PASS: Database backup snapshot generated and listed in UI.")

    print("\n" + "=" * 65)
    print("🎉 ALL DASHBOARD INTEGRATION TESTS PASSED 100%!")
    print("=" * 65)
    return True

if __name__ == "__main__":
    success = run_dashboard_tests()
    if not success:
        sys.exit(1)
