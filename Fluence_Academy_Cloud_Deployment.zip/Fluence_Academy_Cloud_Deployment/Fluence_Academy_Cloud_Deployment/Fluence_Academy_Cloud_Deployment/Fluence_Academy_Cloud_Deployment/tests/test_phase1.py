import asyncio
import sys
from pathlib import Path

# Ensure UTF-8 output on Windows consoles
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select, inspect
from app.database.connection import engine, AsyncSessionLocal
from app.database.models import (
    User, Subscription, Course, Enrollment, Lesson, LessonMaterial,
    StudentProgress, Quiz, QuizQuestion, QuizAnswer, QuizAttempt, Grade, Announcement
)
from app.database.init_db import init_database
from app.core.security import verify_password
from app.core.config import settings

EXPECTED_TABLES = {
    "users",
    "subscriptions",
    "courses",
    "enrollments",
    "lessons",
    "lesson_materials",
    "student_progress",
    "quizzes",
    "quiz_questions",
    "quiz_answers",
    "quiz_attempts",
    "grades",
    "announcements"
}

async def run_phase1_verification():
    print("=" * 65)
    print("🧪 PHASE 1 SYSTEM VERIFICATION & ACCEPTANCE TEST")
    print("=" * 65)

    # 1. Initialize Database
    print("\n[Test 1/4] Running Database Initializer...")
    await init_database()
    print(" -> init_database() completed successfully.")

    # 2. Inspect created tables in database
    print("\n[Test 2/4] Verifying all 13 database tables...")
    async with engine.connect() as conn:
        tables = await conn.run_sync(
            lambda sync_conn: set(inspect(sync_conn).get_table_names())
        )

    missing = EXPECTED_TABLES - tables
    if missing:
        print(f"❌ FAIL: Missing tables: {missing}")
        return False

    print(f"✅ PASS: All {len(EXPECTED_TABLES)} required tables are present in the database:")
    for t in sorted(list(tables)):
        print(f"   • {t}")

    # 3. Check Admin Account & Password Hashing
    print("\n[Test 3/4] Testing Admin account creation & Bcrypt security...")
    async with AsyncSessionLocal() as session:
        query = select(User).where(User.username == settings.DEFAULT_ADMIN_USERNAME)
        result = await session.execute(query)
        admin = result.scalar_one_or_none()

        if not admin:
            print("❌ FAIL: Default admin user was not found.")
            return False

        if not verify_password(settings.DEFAULT_ADMIN_PASSWORD, admin.hashed_password):
            print("❌ FAIL: Admin password verification failed.")
            return False

        print(f"✅ PASS: Admin account verified (ID: {admin.id}, Role: '{admin.role}').")
        print("   Password hashing (Bcrypt) is working properly.")

    # 4. Simulate Student Registration Flow
    print("\n[Test 4/4] Simulating Student registration into SQLite...")
    test_telegram_id = 999999999
    async with AsyncSessionLocal() as session:
        # Clean up any previous test run
        old_user = await session.execute(select(User).where(User.telegram_id == test_telegram_id))
        existing = old_user.scalar_one_or_none()
        if existing:
            await session.delete(existing)
            await session.commit()

        # Insert simulated student
        test_student = User(
            telegram_id=test_telegram_id,
            username="test_student",
            full_name="Sarah Connor",
            role="student",
            is_active=True
        )
        session.add(test_student)
        await session.flush()

        test_sub = Subscription(
            user_id=test_student.id,
            plan_type="free",
            status="active"
        )
        session.add(test_sub)
        await session.commit()

        # Query back
        check_user = await session.execute(select(User).where(User.telegram_id == test_telegram_id))
        verified_student = check_user.scalar_one_or_none()

        if verified_student and verified_student.full_name == "Sarah Connor":
            print(f"✅ PASS: Simulated student registered successfully (ID: {verified_student.id}, Name: '{verified_student.full_name}').")
        else:
            print("❌ FAIL: Could not query back the simulated student.")
            return False

        # Clean up test student
        await session.delete(verified_student)
        await session.commit()

    print("\n" + "=" * 65)
    print("🎉 ALL PHASE 1 ACCEPTANCE TESTS PASSED SUCCESSFULLY!")
    print("=" * 65)
    return True

if __name__ == "__main__":
    success = asyncio.run(run_phase1_verification())
    if not success:
        sys.exit(1)
