@echo off
title Fluence Academy Server
cd /d "%~dp0"
echo ========================================================
echo   Starting Fluence Academy (Bot + Admin Dashboard)...
echo ========================================================
.\.venv\Scripts\python.exe -u run.py
pause
